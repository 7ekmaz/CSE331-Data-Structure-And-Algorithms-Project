

import sys
import argparse

# Compression Decompression
from compress import *
from decompress import *

# XML to JSON
from xml_editor_json import xml_editor_json

# Consistency (Check and Fix)
from consistency_cmd import *

# Minfying
from minify import *

# Formatting
from Formatting_cmd import *

# ParsingToGraph
from ParsingToGraph import *

# Network Analysis
from Network_Analysis_cmd import *

# PostSearch
from PostSearch import *


def run_cli():
    print("Welcome to the XML Editor CLI! Type 'help' to see available commands, or 'exit' to quit.\n")

    while True:
        # Display the prompt and wait for user input
        user_input = input("xml-editor> ").strip()

        # Handle exit or quit commands
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting XML Editor CLI. Goodbye!")
            break

        # Help menu
        elif user_input.lower() == "help":
            print("""
Available commands:
  compress         - Compress an XML file (usage: compress -i input.xml -o output.comp)
  decompress       - Decompress a compressed XML file (usage: decompress -i input.comp -o output.xml)
  json             - Convert XML to JSON (usage: json -i input.xml -o output.json)
  minify           - Minify an XML file (usage: minify -i input.xml -o output.xml)
  format           - Prettify an XML file (usage: prettify -i input.xml -o output.xml)
  verify           - Verify and fix XML consistency (usage: verify -i input.xml [-f] [-o output.xml])
  draw             - Draw a social network graph from XML data (usage: draw -i input.xml -o output.png)
  search           - Search for posts by word or topic (usage: search -i input.xml -w word OR -t topic)
  suggest          - Suggest users based on a target user (usage: suggest -i input.xml -id user_id)
  mutual           - Find mutual followers among users (usage: mutual -i input.xml -ids user_id1,user_id2,...)
  most_influencer  - Find the most influential user (usage: most_influencer -i input.xml)
  most_active      - Find the most active user (usage: most_active -i input.xml)
  exit             - Quit the program
""")

        # Compress XML file
        elif user_input.startswith("compress"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                compress_xml(input_file, output_file)
                print(f"File {input_file} compressed successfully to {output_file}!")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: compress -i input.xml -o output.comp")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Decompress XML file
        elif user_input.startswith("decompress"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                decompress_xml(input_file, output_file)
                print(f"File {input_file} decompressed successfully to {output_file}!")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: decompress -i input.comp -o output.xml")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Convert XML to JSON
        elif user_input.startswith("json"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                xml_editor_json(input_file, output_file)
                print(f"File {input_file} converted successfully to JSON at {output_file}!")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: json -i input.xml -o output.json")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Minify XML
        elif user_input.startswith("mini"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                xml_editor_mini(input_file, output_file)
                print(f"File {input_file} minified successfully to {output_file}!")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: minify -i input.xml -o output.xml")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Prettify XML
        elif user_input.startswith("format"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                data = formatting(input_file)
                with open(output_file, "w") as output_file:
                    for line in data:
                        output_file.writelines(line)
                        output_file.writelines("\n")
                print(f"Formatted XML saved to {output_file}")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")
            except Exception as e:
                print(f"An error occurred while formatting: {e}")

        # Verify XML consistency
        elif user_input.startswith("verify"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                fix = "-f" in parts
                output_file = parts[parts.index("-o") + 1] if "-o" in parts else None

                # Read the XML file
                try:
                    with open(input_file, "r") as file:
                        xml_lines = file.readlines()
                except FileNotFoundError:
                    print(f"Error: The file '{input_file}' was not found.")
                    continue

                # Check XML consistency
                is_valid, errors = check_xml_consistency(xml_lines)
                if is_valid is None:
                    continue

                if is_valid:
                    print("Output: valid, no error found")
                else:
                    print(f"Output: invalid ({len(errors)} errors)")
                    for line_num, error in errors:
                        print(f"Error on line {line_num}: {error}")

                # Fix XML if requested
                if fix:
                    fixed_lines, error_log = fix_xml_consistency(xml_lines, errors)
                    if error_log:
                        print("\nFixes applied:")
                        for log in error_log:
                            print(log)
                    if output_file:
                        with open(output_file, "w") as output_file:
                            output_file.writelines(fixed_lines)
                        print(f"\nFixed XML saved to {output_file}")
                    else:
                        print("\nFixed XML (printed below):")
                        print("".join(fixed_lines))
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: verify -i input.xml [-f] [-o output.xml]")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Draw a social network graph
        elif user_input.startswith("draw"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                output_file = parts[parts.index("-o") + 1]
                graph, posts, user_topics, post_topics, names = parse_xml_to_graph(input_file)
                visualize_graph(output_file, graph)
                print(f"Graph visualization saved to {output_file}!")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: draw -i input.xml -o output.png")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Search for posts by word or topic
        elif user_input.startswith("search"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                if "-w" in parts:
                    word = parts[parts.index("-w") + 1]
                    results = parse_xml_to_graph(input_file)
                    wordSearch(word, results[1])
                elif "-t" in parts:
                    topic = parts[parts.index("-t") + 1]
                    results = parse_xml_to_graph(input_file)
                    topicSearch(topic, results[3])
                else:
                    print("Error: Please provide either a word (-w) or a topic (-t).")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: search -i input.xml -w word OR -t topic")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Suggest users based on a target user
        elif user_input.startswith("suggest"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                user_id = parts[parts.index("-id") + 1]
                graph, posts, user_topics, post_topics, names = parse_xml_to_graph(input_file)
                suggestions = suggest_users(graph, user_id)
                print(f"Suggested users for user {user_id}:")
                for user_id, user_name in suggestions:
                    print(f"ID: {user_id}")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: suggest -i input.xml -id user_id")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Find mutual followers
        elif user_input.startswith("mutual"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                user_ids = [uid.strip() for uid in parts[parts.index("-ids") + 1].split(",")]
                graph, posts, user_topics, post_topics, names = parse_xml_to_graph(input_file)
                mutual_users = mutual_followers(graph, user_ids)
                if mutual_users:
                    print("Mutual users who follow all specified users:")
                    for user_id in mutual_users:
                        print(f"ID: {user_id}")
                else:
                    print("No mutual users found.")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: mutual -i input.xml -ids user_id1,user_id2,...")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Find the most influential user
        elif user_input.startswith("most_influencer"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                graph, posts, user_topics, post_topics, names = parse_xml_to_graph(input_file)
                influencer_name, influencer_id = most_influencer(graph, names)
                print(f"Most Influencer: ID = {influencer_id}, Name = {influencer_name}")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: most_influencer -i input.xml")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Find the most active user
        elif user_input.startswith("most_active"):
            try:
                parts = user_input.split()
                input_file = parts[parts.index("-i") + 1]
                graph, posts, user_topics, post_topics, names = parse_xml_to_graph(input_file)
                username, user_id = most_active_user(graph, names)
                print(f"Most Active User: ID = {user_id}, Name: {username}")
            except (ValueError, IndexError):
                print("Error: Invalid syntax. Usage: most_active -i input.xml")
            except FileNotFoundError:
                print(f"Error: The file '{input_file}' was not found.")

        # Handle unknown commands
        else:
            print(f"Unknown command: {user_input}. Type 'help' for a list of commands.")
