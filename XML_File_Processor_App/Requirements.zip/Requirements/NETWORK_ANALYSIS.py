from XMLGRAPH import parse_xml_to_graph, Graph, visualize_graph

def most_influencer(graph, names):
    followers = {}
    for node in graph.get_all_nodes():
        followers[node] = graph.get_in_degree(node)
    most = max(followers, key=followers.get)
    return names[most], most 

def most_active_user(graph, names): # 1st approach
    activity = {}
    for node in graph.get_all_nodes():
        followers = set(graph.get_followers(node))
        followees = set(graph.get_neighbors(node))
        activity[node] = graph.get_in_degree(node) + graph.get_out_degree(node) - len(followers.intersection(followees))
    most_active = max(activity, key=activity.get)
    return names[most_active], most_active

def mutual_followers(graph, users):
    mutual = []
    for user in users:
        mutual.append(graph.get_followers(user))
    result = list(set.intersection(*map(set, mutual)))
    return result if result else "No mutual followers"

def suggest_users(graph, target_user):
    # Get the direct followers of the target user
    direct_followers = graph.get_followers(target_user)
    suggested_users = set()

    # For each direct follower of the target user
    for follower in direct_followers:
        # Get the second-degree neighbors (followers of the follower)
        second_degree_neighbors = graph.get_followers(follower)
        
        # Suggest a user if they are not the target user, not already a direct follower, and not the follower itself
        for second_degree_user in second_degree_neighbors:
            if second_degree_user != target_user:
                suggested_users.add(second_degree_user)

    # Return the list of suggested users along with their names
    return [(user, user) for user in suggested_users]  # Assuming user names are the same as user IDs